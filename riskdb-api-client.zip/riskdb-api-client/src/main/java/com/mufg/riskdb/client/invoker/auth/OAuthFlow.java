package com.mufg.riskdb.client.invoker.auth;

public enum OAuthFlow {
    accessCode, implicit, password, application
}