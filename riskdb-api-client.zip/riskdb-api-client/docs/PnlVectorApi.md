# PnlVectorApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiPNLVectorGet**](PnlVectorApi.md#apiPNLVectorGet) | **GET** /api/PNLVector | 

<a name="apiPNLVectorGet"></a>
# **apiPNLVectorGet**
> String apiPNLVectorGet(asOfDate, desk, branchId)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.PnlVectorApi;


PnlVectorApi apiInstance = new PnlVectorApi();
String asOfDate = "asOfDate_example"; // String | 
String desk = ""; // String | 
Integer branchId = 1; // Integer | 
try {
    String result = apiInstance.apiPNLVectorGet(asOfDate, desk, branchId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PnlVectorApi#apiPNLVectorGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asOfDate** | **String**|  | [optional]
 **desk** | **String**|  | [optional]
 **branchId** | **Integer**|  | [optional] [default to 1]

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

