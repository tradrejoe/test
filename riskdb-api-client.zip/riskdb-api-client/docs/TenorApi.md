# TenorApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiTenorGet**](TenorApi.md#apiTenorGet) | **GET** /api/Tenor | 

<a name="apiTenorGet"></a>
# **apiTenorGet**
> String apiTenorGet()



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.TenorApi;


TenorApi apiInstance = new TenorApi();
try {
    String result = apiInstance.apiTenorGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TenorApi#apiTenorGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

