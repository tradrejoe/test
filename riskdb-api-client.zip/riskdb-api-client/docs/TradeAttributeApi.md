# TradeAttributeApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiTradeAttributeGet**](TradeAttributeApi.md#apiTradeAttributeGet) | **GET** /api/TradeAttribute | 

<a name="apiTradeAttributeGet"></a>
# **apiTradeAttributeGet**
> String apiTradeAttributeGet(asOfDate, desk, branchId)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.TradeAttributeApi;


TradeAttributeApi apiInstance = new TradeAttributeApi();
String asOfDate = "asOfDate_example"; // String | 
String desk = "desk_example"; // String | 
Integer branchId = 56; // Integer | 
try {
    String result = apiInstance.apiTradeAttributeGet(asOfDate, desk, branchId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TradeAttributeApi#apiTradeAttributeGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asOfDate** | **String**|  | [optional]
 **desk** | **String**|  | [optional]
 **branchId** | **Integer**|  | [optional]

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

