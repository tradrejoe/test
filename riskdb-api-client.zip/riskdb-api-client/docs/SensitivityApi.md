# SensitivityApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiSensitivityGet**](SensitivityApi.md#apiSensitivityGet) | **GET** /api/Sensitivity | 
[**apiSensitivityPost**](SensitivityApi.md#apiSensitivityPost) | **POST** /api/Sensitivity | 

<a name="apiSensitivityGet"></a>
# **apiSensitivityGet**
> String apiSensitivityGet(asOfDate, desk, branchId)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.SensitivityApi;


SensitivityApi apiInstance = new SensitivityApi();
String asOfDate = "asOfDate_example"; // String | 
String desk = ""; // String | 
Integer branchId = 1; // Integer | 
try {
    String result = apiInstance.apiSensitivityGet(asOfDate, desk, branchId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SensitivityApi#apiSensitivityGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asOfDate** | **String**|  | [optional]
 **desk** | **String**|  | [optional]
 **branchId** | **Integer**|  | [optional] [default to 1]

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

<a name="apiSensitivityPost"></a>
# **apiSensitivityPost**
> String apiSensitivityPost(body)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.SensitivityApi;


SensitivityApi apiInstance = new SensitivityApi();
List<SensitivityResponse> body = Arrays.asList(new SensitivityResponse()); // List<SensitivityResponse> | 
try {
    String result = apiInstance.apiSensitivityPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SensitivityApi#apiSensitivityPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**List&lt;SensitivityResponse&gt;**](SensitivityResponse.md)|  | [optional]

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

