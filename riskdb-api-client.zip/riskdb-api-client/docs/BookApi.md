# BookApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiBookGet**](BookApi.md#apiBookGet) | **GET** /api/Book | 

<a name="apiBookGet"></a>
# **apiBookGet**
> String apiBookGet(asOfDate, desk, branchId)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.BookApi;


BookApi apiInstance = new BookApi();
String asOfDate = "asOfDate_example"; // String | 
String desk = ""; // String | 
Integer branchId = 1; // Integer | 
try {
    String result = apiInstance.apiBookGet(asOfDate, desk, branchId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BookApi#apiBookGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asOfDate** | **String**|  | [optional]
 **desk** | **String**|  | [optional]
 **branchId** | **Integer**|  | [optional] [default to 1]

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

