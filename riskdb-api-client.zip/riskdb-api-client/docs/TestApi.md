# TestApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiTestGet**](TestApi.md#apiTestGet) | **GET** /api/Test | 

<a name="apiTestGet"></a>
# **apiTestGet**
> String apiTestGet()



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.TestApi;


TestApi apiInstance = new TestApi();
try {
    String result = apiInstance.apiTestGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TestApi#apiTestGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

