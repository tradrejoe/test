# TokenApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiTokenPost**](TokenApi.md#apiTokenPost) | **POST** /api/Token | 

<a name="apiTokenPost"></a>
# **apiTokenPost**
> apiTokenPost(body)



### Example
```java
// Import classes:
//import com.mufg.riskdb.client.invoker.ApiException;
//import com.mufg.riskdb.client.api.TokenApi;


TokenApi apiInstance = new TokenApi();
UserInfo body = new UserInfo(); // UserInfo | 
try {
    apiInstance.apiTokenPost(body);
} catch (ApiException e) {
    System.err.println("Exception when calling TokenApi#apiTokenPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UserInfo**](UserInfo.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: Not defined

