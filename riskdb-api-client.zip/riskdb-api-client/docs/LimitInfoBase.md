# LimitInfoBase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limitId** | **Integer** |  |  [optional]
**parentLimitId** | **Integer** |  |  [optional]
**limitValue** | **Double** |  |  [optional]
**startDate** | **String** |  |  [optional]
**endDate** | **String** |  |  [optional]
