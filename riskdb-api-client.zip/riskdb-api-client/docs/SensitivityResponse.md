# SensitivityResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tradeId** | **String** |  |  [optional]
**sensitivityValue** | **Float** |  |  [optional]
